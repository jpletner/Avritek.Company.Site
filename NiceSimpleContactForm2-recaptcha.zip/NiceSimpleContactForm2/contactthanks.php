<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">

<head>
	<title>A Nice & Simple Contact Form</title>
	
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>

    <?php include("../header.php"); ?>

	<div id="page-wrap">

		<img src="images/title.gif" alt="A Nice & Simple Contact Form" />
		<p>By <a href="http://css-tricks.com">CSS-Tricks</a></p>
			
			
		<br /><br />
		
			
		<h1>Your message has been sent!</h1><br />
		
		<p><a href="index.php">Back to Contact Form</a></p>
	
	</div>
	
	<?php include("../footer.php"); ?>

</body>

</html>