<?php
/**
 * The template for comments and comment form.
 *
 * @since BlogCentral 1.0.0
 *
 * @package BlogCentral
 * @subpackage comments.php
 */
	
// Call function in functions.php to display the comments.
blogcentral_comments_layout();