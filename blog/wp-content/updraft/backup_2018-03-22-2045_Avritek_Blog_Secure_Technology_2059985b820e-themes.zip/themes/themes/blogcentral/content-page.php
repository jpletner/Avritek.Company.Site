<?php
/**
 * Template for page type content.
 *
 * @since BlogCentral 1.0.0.
 *
 * @package BlogCentral
 * @subpackage content-page.php
 */

the_content(); 